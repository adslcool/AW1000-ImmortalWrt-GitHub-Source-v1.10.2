# v1.2.1 实机日志分析与修复

输入：用户提供的 2026-10-19 诊断文本，包含 qmodem/network UCI、ip link 和系统日志。

## 日志已确认

- `qmodem.main.enable_dial=1`，实例 `4_1` 的 `enable_dial=1`、`state=enabled`、`host_ipv4_owner=netifd`，机型登记标记为 1。
- `network.wwan0` 存在，`modem_config=4_1`、`proto=qmodem_runtime`、`device=wwan0`；内核也存在该设备。
- 日志曾经历连接丢失、重拨，随后最后一轮为 `Interface 'wwan0' is now up`。这说明诊断时并非接口一直未生成，但不能据此确认此刻仍可上网。
- `qmodem-uplink-watch` 持续报 jq 编译时未包含 ONIGURUMA，`match/test/sub` 不可用。
- 另有 `notify_proto ... Permission denied`，但随后接口仍进入 up 状态。当前证据不足以将其认定为持续权限故障，没有修改权限或绕过 netifd 校验。修复 jq 后若仍出现掉线，需要新的完整时序与接口状态。
- 日志显示的日期与提交日期不同，不能据此对齐真实掉线时间；本次不修改路由器时钟或 NTP。

## 根因与改动

锁定的官方 packages jq 1.8.1-r2 Makefile 定义两个变体：普通 `jq` 为 `noregex` 默认变体，编译参数 `--without-oniguruma`；`jq-full` 提供 `jq` 能力并依赖 `oniguruma`，编译参数 `--with-oniguruma`。

QModem 主备检查中使用 `test()` 等正则函数，前版只依赖普通 jq，遗漏了变体差异。不是缺少 jq 可执行文件，也不是再建立一个同名 wwan0 就能解决。

v1.2.1 显式设置 `CONFIG_PACKAGE_jq-full=y`、`CONFIG_PACKAGE_oniguruma=y`，将 `CONFIG_PACKAGE_jq` 设为 n。最终产物清单必须含 `jq-full` 和 `oniguruma`，不得含普通 `jq`。现有依赖中的 `+jq` 能由 jq-full 的 PROVIDES 满足，实际 defconfig 已验证不会被重新强制选择成无正则变体。

USB 打印、LED、Xray 兼容处理、LuCI 协议文件和其他路由功能保持原有选择。

## 实际验证与边界

- 在已有真实正式版源树安装 jq-full/oniguruma 源码入口，并重新运行 `make defconfig`。
- 所有指定 y/n 选项符合要求；选择 386 个软件包，jq-full/oniguruma 选中、普通 jq 未选中。
- QModem 上游健康阈值及 SSR 标记兼容检查通过；修改的 Python 脚本语法通过。
- 此次不将宿主机 jq 的正则可用性作为目标固件已经修好的证据；目标镜像需要 GitHub 全量编译并核对 manifest。
- 未生成新固件，未在用户设备执行写操作或进行真实网络切换测试。

重新构建建议固定 `v25.12.2`。刷入后可用以下只读命令确认：

```sh
jq -ne '"wwan0" | test("^wwan[0-9]+$")'
ifstatus wwan0
logread | grep -Ei 'qmodem-uplink|netifd' | tail -n 50
```

第一条应输出 true 并成功退出；第二条结合 up、IPv4 地址和路由判断当前拨号状态。若网页仍不显示而 ifstatus 正常，应继续检查前端加载及缓存，不再额外新建同名接口。
