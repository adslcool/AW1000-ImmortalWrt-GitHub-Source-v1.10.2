# v1.2.0 改动与使用

## 截图中的 wwan0 错误

截图提示“不支持的协议类型。安装扩展协议…”。锁定 QModem 的 `modem_dial.sh` 在托管 IPv4 模式下将接口协议设为 `qmodem_runtime`，且提供 `/lib/netifd/proto/qmodem_runtime.sh`；锁定版本没有相应 LuCI JavaScript 协议。

新增 `files/qmodem_runtime.js`，生成固件 overlay 时安装到 `/www/luci-static/resources/protocol/qmodem_runtime.js`。协议显示为 QModem managed IPv4，通过运行状态取得实际设备，实例信息只读。仍由 QModem 原后端管理 PDP、地址和路由。构建配置阶段检查该后端确实存在，固件收集时核对前后端均进入目标根文件系统。

截图本身不能证明拨号失败；这项修改解决界面的协议识别，不更改为 DHCP，不重新生成 network 配置。运行中的设备可仅上传此 JS 文件后 Ctrl+F5 刷新，USB 打印与 LED 功能则需安装组件或重新编译固件。

## USB 打印

新增 `kmod-usb-printer`、`p910nd`、`luci-app-p910nd`。保持上游默认禁用实例。在网络存储的 p910nd 打印服务器页面中选择实际设备（通常 `/dev/usb/lp0`），端口索引 0 对应 RAW TCP 9100。电脑侧用路由器 LAN IP 建立标准 TCP/IP 打印端口并安装原厂驱动。设备识别和双向通信兼容性需要实际打印机验证，不提供扫描功能。

## LED 插件

上游：https://github.com/nooblk-98/luci-app-aw1k-led

固定提交：`2419f9cf1154fca74ac29f77b486ec2709304d43`，版本 1.0.3。

构建阶段从锁定提交下载到 `work/vendor/aw1k-led`，安装到 `package/custom/luci-app-aw1k-led`。

适配内容：

- 增加 `python3-light`、`jq`、`ubus-at-daemon` 依赖，保留上游 sms-tool 依赖。
- 使用标准 LuCI `htdocs/`、`root/` 安装规则，去除重复的 BuildPackage 调用，保留原作者和 GPL 声明；实际元数据仅有一个同名软件包。
- 显式修正 init、uci-defaults、RPC 和 LED 脚本的可执行权限。
- 将原脚本中的直接 `sms_tool` 调用改为 `/usr/sbin/aw1000-led-at`；仅允许两种 LED 信号查询，经 `at-daemon sendat` 队列发送，JSON 正确保留命令引号。初始化占用串口时不绕过租约；失败或 busy 结果不会伪装成成功。

菜单：系统 → AW1000 LEDs。上游自动启用服务；夜间模式默认关闭。电话灯部分未增加电话服务，不代表 RJ11 可通话。

## 验证边界

真实 defconfig 选中 385 个软件包、全部指定选项保留；实际 LED 元数据依赖已包含 Python 和 AT 队列。28 项本地测试、所有新增脚本语法和上游纯逻辑健康 / 标记检查通过。

本地索引涵盖所需 packages/luci/helloworld/qmodem，未建立正式版其他三个 feed 的索引。GitHub 工作流仍正常更新全部正式版 feeds，并核对最终 manifest 与目标根文件系统。此处未进行全量交叉编译、LuCI 浏览器真机操作、串口实测、LED 实测或打印实测。

此前 v1.1.1 的官方 Xray 来源选择及 Go 兼容检查保留。建议重新运行 GitHub Actions 时填入 `v25.12.2`，覆盖仓库时包含 `.github` 目录。
