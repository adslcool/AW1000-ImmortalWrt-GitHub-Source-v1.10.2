# v1.4.1 自动 PCM 初始化

fxsd 的 procd 包装器在真实 AT 端口出现后调用 aw1000-phone-setup auto。默认开启；仅自动端口选择模式生效。自动动作在服务子进程内执行，不阻塞 init 启动、不递归 restart 自身。

状态位于 /etc/config/fxs 的 pcm_auto_state：无状态时读取 QDAI，slave 直接写 done；master 先提交 attempted 并 sync，再设置 QDAI 与重启模组，确认命令成功后写 done。AT 未就绪或无法解析响应时退出 75，由包装器等待三秒后重试；尚未消费配置尝试。实际修改失败、重启失败或过程中整机重启时，attempted 保留，后续禁止重复自动修改和重启。手动 configure 仍可在排查后重试。

用户可设置 auto_pcm=0，或在 LuCI 高级选项关闭自动初始化。手动指定 AT 端口时不自动修改模组 PCM。首次需要配置时蜂窝连接会短暂断线；SIM 仍须支持语音与 VoLTE。

54 项回归测试通过。未完成完整固件编译及实机启动／通话验证。本版软件包集合与 v1.4.0 相同，实际 defconfig 记录沿用该版本。
