# v1.5.0 主备迁移

## 固定来源

mwan3-nft v3.6.12-1：cdd4fc56f4de9ccf56d40d6dc04a5b6a4e5a0ae6。
对应 LuCI v3.6.12-1：1e8513a69cff32da3dd82c342151cdb4a991c2b7。
两者均为 GitHub 非预发布标签，原始源码归档及 SHA-256 随工程，不安装其他固件的预编译 APK。GPL 许可保留于源码包。脚本适配 LuCI include 路径，并把 libnetfilter_conntrack 构建依赖引用修正为源码目录名 libnetfilter-conntrack。

## 唯一 IPv4 管理器

mwan3-nft 原生健康探测与策略选路取代 QModem uplink；旧管理器不安装，保留配置升级时关闭其配置。QModem 继续拨号和恢复。mwan3 成员优先级有线 1、蜂窝 2，系统 metric 10/200。每轮间隔 10 秒，每目标超时 2 秒，任一国内目标成功为通过；失败 3 次，恢复 7 次成功。恢复首末成功样本间至少约 60 秒，算法不再是旧版 3 次成功加独立 60 秒计时。初始 offline 也需成功阈值，因此首次启动会等待探测。

## 联动与隔离

所有 mwan3 配置均为 IPv4 family，IPv6 不单独探测。每 2 秒读取已安装 nft 链 mwan3_policy_aw_failover 的实际选择，使用标准成员 ID 到接口的顺序映射，兼容 nft 的 OR/XOR 等价显示。无有效策略或全断时不启用任一上游 IPv6。停止备用 DHCPv6，由 netifd 管理地址／前缀撤回，再恢复选中接口。当前出口没有 IPv6 时不跨线路兜底。该轮询和 RA/DHCPv6 收敛会产生时间差，不保证 IPv6 会话无缝迁移。

DNS 运行时片段仅包含当前选中线路的 IPv4 DNS，缺省使用国内 DNS。保留用户手工 DNS／分域配置及其文件，服务退出只清理自己的片段。蜂窝恢复适配通过 qmodem-uplink-health 约定返回 mwan3 tracker 状态；这是轻量适配器，不是被移除的旧管理器。未知、connecting、PID 无效或样本超过 60 秒均延后恢复，避免误触发重拨；在线／disconnecting 视为未达到失败阈值，offline 才交给已有恢复流程。

SSR 标记低位 0x5250/0x0000ffff，mwan3 高位 0x00ff0000。保留 TPROXY 本地路由优先级 999，在 mwan3 前匹配。首次迁移关闭 flow offload 和 IPv4 FullCone。高位掩码不要任意改动；改变为其它掩码时联动器会拒绝继续推导选择并记录日志。

## 验证与限制

63 项回归、实际 defconfig、源代码标记兼容检查与 WDA 编码测试通过；384 个选中包。未执行完整固件编译、目标驱动编译或真机流量测试。构建镜像收集阶段会拒绝缺失 mwan3 原生 nft 文件、健康适配器、电话补丁和驱动的镜像，并拒绝同时包含旧主备管理器。

升级会一次性保存 /etc/config/mwan3.pre-aw1000，并设置本项目默认主备策略；后续修改与保留配置升级不反复覆盖。已有 TCP、UDP 和 IPv6 会话仍可能需要重连。电话、USB 打印、Raw-IP 与国内镜像保留。
