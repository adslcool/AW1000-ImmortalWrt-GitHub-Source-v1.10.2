# v1.2.2：AW1000 RG500Q-EA Raw-IP 修复

## 实机证据

用户设备使用通用 `qmi_wwan`。netifd 已取得 IPv4、网关和 DNS，指定设备的策略路由指向蜂窝网关，反向路径过滤为 0；但 Raw-IP 为 N，网卡显示 Ethernet，RX 始终为 0。

按 `ifdown → link down → raw_ip=Y → link up → ifup` 临时切换后：

- Raw-IP 为 Y，设备显示 `POINTOPOINT/NOARP`、`link/none`。
- 外网 Ping 4 发 4 收，0% 丢包，平均约 48ms。
- RX 从 0 增至 420 字节、5 个包。

这支持主机数据格式错配是本次数据面故障的直接原因。此前 jq 正则库缺失仍影响主备切换，两处需要分别修复。

## 新初始化流程

1. 安装 `/usr/sbin/aw1000-qmi-prepare`。
2. 在 QModem 的托管 QMI 拨号重试循环中、启动 CM 之前调用。
3. 校验实例和设备名，确认机型为 AW1000、模块为 RG500Q-EA、USB、host_ipv4_owner=netifd、实际驱动为通用 qmi_wwan。
4. 模式为 Y 时直接返回，不打断现有链路。模式为 N 时，记录 IFF_UP、关物理链路、写 Y、核验结果，并通过退出处理恢复原链路状态。原本关闭的设备不主动打开。
5. 准备失败时记录错误、等待后重试，不继续启动已知格式错误的拨号过程。

这不是仅运行一次的首启 UCI 设置，也不依赖固定 USB 总线路径；后续重拨会再次检查实际 netdev。

## 模块端协商匹配

供应商 CM 原非 QMAP WDA 请求默认 Ethernet。只在拨号前改主机模式不足以保证后续重新协商仍匹配。因此，补丁为请求构造函数传入独立上下文：托管模式且实际主机 sysfs 为 Y/1 时请求 Raw-IP（2）；其余非 QMAP 情况继续请求原 Ethernet（1）；原 QMAP 分支仍使用 Raw-IP。

没有修改 QMAP_SETTING 结构体布局或驱动 ioctl ABI。协商结果仍由原 CM 解析。

## 验证

- 34 项标准库测试通过，新增覆盖切换后恢复原链路状态、重复执行不切链路、原来关闭的设备不拉起、不匹配的机型/驱动/模块/所有者不修改、异常时尝试恢复、非法设备名拒绝、拨号补丁位置及幂等。
- 在真实锁定 QModem 源码应用补丁、检查重复应用不变；新增 helper 与修改后的拨号脚本 Shell 语法通过。
- 真实修改后的 QMIThread.c 通过宿主 GCC 语法检查。
- `tests/check_qmi_format.py` 在宿主编译并运行 `cm_format_harness.c`，使用真实的供应商 WDA 构造函数，断言三种数据格式编码。工作流新增同一检查。
- helper 已进入生成 overlay、设置可执行权限，并加入最终目标根文件系统的必需文件检查。

包选择与 v1.2.1 相同，保留 jq-full/oniguruma、USB 打印和 LED。

没有完整固件交叉编译、没有新自动初始化版本的真实重启/热插拔验证、没有完整 CM 程序真机协商或长期流量测试。现有实机成功结果仅证明临时手动切换 Raw-IP 能恢复网络。
