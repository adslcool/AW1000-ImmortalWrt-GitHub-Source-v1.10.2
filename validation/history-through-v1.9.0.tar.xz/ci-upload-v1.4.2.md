# GitHub 检查失败修复 v1.4.2

实际失败：adslcool/AW1000-ImmortalWrt-GitHub-Source-v1.4.1，run 39256186888，job 118071955621，提交 b633071fff738c32f9c8f90f9454cb707a03bd51。

Test provisioning and input validation 执行了 54 项测试，唯一错误在 phone.install 的 vendored source inventory 检查。对比实际仓库文件树，网页上传遗漏 vendor/openwrt-aw1000-phone/.gitignore。它不参与编译，却被清单要求必须存在。Node.js 警告不是导致此次失败的原因；语法检查当时尚未运行。

修复保留严格源码校验：只将 .gitignore 作为允许缺少的辅助文件，存在时仍校验其哈希；构建源码缺少、额外文件或源码哈希变化仍拒绝。错误信息列出具体缺失／多出文件。

新增自动化测试模拟网页上传省略该文件，并验证 modem.c 缺少或改动仍失败。56 项测试通过。此修复未在用户 GitHub 仓库推送，需覆盖上传后重新运行 Actions；不等同于云端完整固件编译已成功。

本地复跑 CI 的 Python 编译检查、ShellCheck、所有 shell 语法、Lua 与 Node 语法检查均通过。
