# v1.3.0 IPv6 行为与验证

用户要求：处理 IPv6，主备切换逻辑仅使用 IPv4。

## 行为

- RG500Q-EA 首次登记或旧版本迁移时选择 ipv4v6 PDP。
- IPv4 继续走 QModem 的 `qmodem_runtime`，由现有 IPv4 主备管理器探测和选择出口。
- IPv6 使用 QModem 原生的独立 DHCPv6 接口。接口名为 IPv4 逻辑名加 `v6`，通常为 `wwan0v6`，设备为 `@wwan0`。
- IPv6 默认尝试请求地址和自动申请前缀，启用 delegate 与 extendprefix，以支持运营商仅提供单 /64 的场景。该方式与源码树官方 QMI DHCPv6 路径采用的前缀扩展一致。
- LAN 缺少 ip6assign 时补为 64，缺少 RA/DHCPv6/SLAAC 选项时补服务器默认值；已有自定义值保留，不强制切换为 RA relay。
- 既有 IPv6 接口的用户显式配置保留，只补缺失客户端默认值；接口仍加入原 QModem 的 WAN 防火墙区域。
- 初始接口 metric 为有线 10、蜂窝 200，IPv6 按常规路由和源前缀选择，不根据 IPv4 探测结果切换、撤销或重新发布前缀。

IPv6 可以在 IPv4 当前选择有线时仍使用蜂窝来源的前缀；这是两个协议分别运行的结果。没有增加 IPv6 健康检测、会话迁移、NAT6 或保证与 IPv4 同步的策略。

IPv4/IPv6 共享同一模组数据会话，蜂窝异常恢复触发整条 PDP 重拨时，IPv6 仍可能一起短暂中断；这不代表 IPv6 加入了主备探测。

## 迁移和地址管理

独立的 `aw1000_ipv6_initialized` 标记解决旧 `aw1000_uplink_initialized=1` 导致跳过新功能的问题。迁移不改 APN、不重新启用用户关闭的拨号、不修改 IPv4 主备参数。若已有 CM 进程，释放配置锁后调用原生 `qmodem_network reconfigure`，该入口遵守当前 enable_dial。之后的重复扫描不再次重拨、不覆盖用户新修改的 PDP 类型。

托管模式下，CM 仍请求建立 IPv4/IPv6 数据会话，但不再直接向内核写入 IPv6 地址、路由和 DNS；由 odhcp6c 的 RA/DHCPv6 路径向 netifd 发布，确保 LuCI 与路由器状态一致。非托管旧模式继续原行为。

## 验证结果

- 35 项单元/边界集成测试通过。
- 旧版本仅 IPv4 设置迁移为双栈，APN、停拨状态、IPv4 探测间隔、已有 LAN 前缀长度和 RA 自定义值保持原状，迁移仅重配置一次。
- 真实源树 defconfig 全部指定选项保留，386 个软件包；IPv6、odhcp6c、odhcpd-ipv6only、luci-proto-ipv6 明确选中。
- 实际供应商 C 源码语法检查、WDA 报文编码宿主检查、修改后拨号脚本语法和上游主备健康/SSR 标记测试通过。
- 最终 manifest 必须包含 IPv6 客户端、RA/DHCPv6 服务与 LuCI 协议，目标根文件系统必须含 DHCPv6 后端和客户端程序。

尚未执行完整固件交叉编译或用户设备上的双栈拨号、IPv6 地址/前缀获取、LAN 公网 IPv6、重启和热插拔测试。运营商/APN 不提供 IPv6 时不会凭空生成公网地址；保留的用户自定义 LAN 策略也可能需要对应调整。

## 刷入后的检查

建议固定 `v25.12.2` 编译。保留配置升级时也会运行一次迁移。通常在网络 → 接口中分别查看 wwan0 与 wwan0v6，IPv6 不一定显示在 IPv4 那一行。

```sh
uci -q get qmodem.4_1.pdp_type
ifstatus wwan0v6
ip -6 addr show dev br-lan
ip -6 route show
```

实例编号、别名不同时替换为实际值；只有取得有效 IPv6 地址和路由后，再测试公网 IPv6 通信及 LAN 终端地址。
