# v1.4.0 RJ11 集成

上游固定提交 2d3d16cf2c7d8d74e5cbc1e0f8f6461d5198c613。完整原始源码位于 vendor，逐文件清单位于 vendor/phone-source-sha256.json；prepare.py 将其部署到 ImmortalWrt 的 aw1000-phone 和三个 package/custom 软件包目录。共享源代码路径显式设为 $(TOPDIR)/aw1000-phone；不采用上游 SDK 预编译 APK，也不伪造内核 vermagic。

内置用户提供的 DSP 文件，大小 908，补丁 ID 0x05262017，191 数据字（含结束零）、16 入口与 16 辅助 RAM。哈希与结构在准备编译时验证；收集固件时再检查 rootfs 字节及驱动文件。保留零值 RAM 配置，原始 C 解析器测试也覆盖截断、追加垃圾和错误 magic。

电话服务启动由 procd 包装器等待 QModem 扫描到真实 AT 端口；仅接受唯一 USB RG500Q-EA，端口不明确时等待，不猜测 ttyUSB2。手动设置有效 ttyUSB 端口仍可使用。所有电话 AT 指令经 at-daemon sendat 队列，owner=aw1000-phone；JSON 非 success 状态作为失败返回，不抢占串口。内核模块由 fxsd 初始化流程加载，保留上游启动保护。

首次音频设置由用户显式执行 aw1000-phone-setup configure：先读取 QDAI；master 时设置 slave 并重启模组；已为 slave 时只启用并重启电话服务。上游要求的 CFUN 重启只在配置过程中发送，不在普通开机执行。此过程中蜂窝会短暂断线。未知响应、AT 排队失败或设置失败时不会继续发送重启。

phone-v1.4.0 验证：48 项测试、真实 defconfig 和两个用户态程序宿主编译通过。电话内核驱动仍需完整固件编译确认，通信功能需具备 VoLTE 的 SIM 和实际设备验证。
