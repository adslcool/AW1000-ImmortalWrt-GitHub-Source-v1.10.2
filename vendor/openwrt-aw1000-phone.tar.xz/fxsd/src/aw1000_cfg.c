// SPDX-License-Identifier: GPL-2.0
// Copyright (C) 2026 perz3us
#include "si_line.h"

const struct si_gen_cfg aw1000_gen_cfg = {
	.device_key = 0x65,
	.bom_opt = SI_BO_LCUB,
	.bat_type = SI_BAT_TRACKING,
	.bat_hyst = 0x000AD000,
	.vbatr_expect = 0x08D4FDB0,
	.vbath_expect = 0x03D70A20,
	.pwrsave_timer = 0x0FFF0000,
	.offhook_thresh = 0x01999A00,
	.vbat_track_min = 0x00F00000,
	.vbat_track_min_rng = 0x00F00000,
	.pwrsave_dbi = 0x00014000,
	.dcdc_ana_scale = 0x0ADD5500,
	.vov_bat_pwrsave_min = 0x00312700,
	.vov_bat_pwrsave_min_rng = 0x00395800,
	.therm_dbi = 0x00800000,
	.cpump_dbi = 0x00004000,
	.dcdc_verr = 0x00F18900,
	.dcdc_verr_hyst = 0x00809D80,
	.dcdc_oithresh_lo = 0x00000000,
	.dcdc_oithresh_hi = 0x01A00000,
	.pd_uvlo = 0x00400000,
	.pd_ovlo = 0x00400000,
	.pd_oclo = 0x00200000,
	.pd_swdrv = 0x00400000,
	.dcdc_uvhyst = 0x00500000,
	.dcdc_uvthresh = 0x00000000,
	.dcdc_ovthresh = 0x01700000,
	.dcdc_oithresh = 0x00800000,
	.dcdc_swdrv_pol = 0x00000000,
	.dcdc_uvpol = 0x00000000,
	.dcdc_vref_man = 0x00000000,
	.dcdc_vref_ctrl = 0x00000000,
	.dcdc_rngtype = 0x00200000,
	.dcdc_ana_vref = 0x05B00000,
	.dcdc_ana_gain = 0x00300000,
	.dcdc_ana_toff = 0x00138000,
	.dcdc_ana_tonmin = 0x00050000,
	.dcdc_ana_tonmax = 0x00310000,
	.dcdc_ana_dshift = 0x00F00000,
	.dcdc_ana_lpoly = 0x0FDA4000,
	.dcdc_aux_invert = 0x00000000,
	.dcdc_cpump_lp = 0x00400000,
	.dcdc_cpump_pulldown = 0x00000000,
	.dcdc_lift_en = 0x00000000,
	.coef_p_hvic = 0x07FE4B00,
	.p_th_hvic = 0x0048D15B,
	.vdc_range = 5,
	.auto_reg = 0x3F,
	.irqen = { 0x50, 0x13, 0x03, 0x00 },
	.enhance = 0x10,
	.scale_kaudio = 0x03A2E8BA,
	.zcal_en = 0x04,
	.lkg_ofhk_offset = 0x03000000,
	.lkg_lb_offset = 0x05000000,
	.vbath_delta = 0x01000000,
	.uvthresh_max = 0x03700000,
	.uvthresh_scale = 0x04B80200,
	.uvthresh_bias = 0x00823000,
};

const struct si_dcfeed aw1000_dcfeed = { {
	0x1C8A024C, 0x1F909679, 0x0040A0E0, 0x1D5B21A9, 0x1DD87A3E, 0x05A38633,
	0x050D2839, 0x03FE7F0F, 0x00B4F3C3, 0x005D0FA6, 0x002D8D96, 0x005B0AFB,
	0x006D4060, 0x00008000, 0x0048D595, 0x003FBAE2, 0x00008000, 0x000F0000,
	0x00080000, 0x00140000, 0x00140000, 0x01BA5E35, 0x0051EB85, 0x00415F45,
} };

const struct si_ring aw1000_ring = {
	.rtper = 0x00050000,
	.freq = 0x07EFE000,
	.amp = 0x001B7243,
	.phas = 0,
	.offset = 0,
	.slope_ring = 0x15E5200E,
	.iring_lim = 0x009FC50F,
	.rtacth = 0x00690508,
	.rtdcth = 0x0FFFFFFF,
	.rtacdb = 0x00006000,
	.rtdcdb = 0x00006000,
	.vov_ring_bat = 0x0051EB82,
	.vov_ring_gnd = 0,
	.vbatr_expect = 0x04DE89D7,
	.talo = 0x80,
	.tahi = 0x3E,
	.tilo = 0x00,
	.tihi = 0x7D,
	.vbat_track_min_rng = 0x01893740,
	.ringcon = 0x98,
	.userstat = 0,
	.vcm_ring = 0x026F44EB,
	.vcm_ring_fixed = 0x026F44EB,
	.delta_vcm = 0x003126E8,
	.dcdc_rngtype = 0x00200000,
};

const struct si_imp aw1000_imp_600 = {
	.txeq = { 0x07F97D80, 0x0006CC00, 0x1FFC1480, 0x1FFC7B80 },
	.rxeq = { 0x07F36B80, 0x000A8E00, 0x1FF90F00, 0x1FFAE500 },
	.ec = { 0x001AF400, 0x1FC86A80, 0x01E9AE00, 0x00652F00, 0x01F4AF00, 0x1F57E000,
		0x00485E00, 0x1FF3A680, 0x1FF83700, 0x00011D00, 0x01706980, 0x066A8480 },
	.zs = { 0x00920F00, 0x1EE31980, 0x008ADF00, 0x0F92E500, 0x186CE880 },
	.ra = 0x53,
	.txgain = 0x085C6880,
	.rxgain = 0x013E3100,
	.hpf = { 0x07AF6F80, 0x18509100, 0x075EDF00 },
	.txgain_db = 0,
	.rxgain_db = 0,
};

const struct si_tone aw1000_dialtone = {
	.osc = {
		{ .freq = 0x079C0000, .amp = 0x000E2000 },
		{ .freq = 0x079C0000, .amp = 0x000E2000 },
	},
	.omode = 0x66,
};

const struct si_tone aw1000_busytone = {
	.osc = {
		{ .freq = 0x079C0000, .amp = 0x000E2000, .talo = 0xA0, .tahi = 0x0F, .tilo = 0xA0, .tihi = 0x0F },
		{ .freq = 0x079C0000, .amp = 0x000E2000, .talo = 0xA0, .tahi = 0x0F, .tilo = 0xA0, .tihi = 0x0F },
	},
	.omode = 0x66,
};

const struct si_tone aw1000_ringbacktone = {
	.osc = {
		{ .freq = 0x079C0000, .amp = 0x000E2000, .talo = 0x40, .tahi = 0x1F, .tilo = 0x00, .tihi = 0x7D },
		{ .freq = 0x079C0000, .amp = 0x000E2000, .talo = 0x40, .tahi = 0x1F, .tilo = 0x00, .tihi = 0x7D },
	},
	.omode = 0x66,
};

const struct si_tone aw1000_waitingtone = {
	.osc = {
		{ .freq = 0x079C0000, .amp = 0x000E2000, .talo = 0x60, .tahi = 0x09, .tilo = 0x40, .tihi = 0x9C },
		{ .freq = 0x079C0000, .amp = 0x000E2000, .talo = 0x60, .tahi = 0x09, .tilo = 0x40, .tihi = 0x9C },
	},
	.omode = 0x66,
};
